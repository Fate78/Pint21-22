import java.rmi.Remote;
import java.rmi.RemoteException;

public interface EstabilizadorInterface extends Remote {
    public String correrScript(Script script) throws RemoteException;
}
