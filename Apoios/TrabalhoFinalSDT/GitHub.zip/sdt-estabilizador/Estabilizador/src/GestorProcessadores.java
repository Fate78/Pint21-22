import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class GestorProcessadores extends Thread {

    private HashMap<UUID, EstadoProcessador> estadosProcessadores = new HashMap<>();
    private MulticastReceiver multicastReceiver;

    public void run()
    {
        while(true) {
            // Faz 5 leituras, com intervalos de 1 segundo da utilização do CPU
            try {
                TimeUnit.SECONDS.sleep(1);
                for (UUID uidEstadoProcessador : estadosProcessadores.keySet())
                {
                        if(!estadosProcessadores.get(uidEstadoProcessador).verificaAtivo()) {
                            estadosProcessadores.remove(uidEstadoProcessador);
                            EstadoProcessador processadorMaisRecursos = this.obterProcessadorMaisRecursos();
                            ProcessadorInterface p = (ProcessadorInterface) Naming.lookup("rmi://localhost:"+processadorMaisRecursos.getPort()+"/processor");
                            p.substituirProcessador(uidEstadoProcessador.toString());
                        }
                }
            } catch (InterruptedException | RemoteException e) {
            } catch (NotBoundException e) {
                e.printStackTrace();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
        }
    }

    public GestorProcessadores()
    {
        multicastReceiver = new MulticastReceiver("230.0.0.0", 4446, new CallbackMulticast() {
            @Override
            public void onMessageReceived(String message) {
                tratarMensagem(message);
            }
        });
        multicastReceiver.start();
    }

    public void adicionarProcessador(UUID objectID, int port)
    {
        estadosProcessadores.put(objectID, new EstadoProcessador(objectID, port));
    }

    public void guardarRecursosProcessador(EstadoProcessador estadoProcessador) {
        estadosProcessadores.put(estadoProcessador.getObjectID(), estadoProcessador);
    }

    public EstadoProcessador obterProcessadorMaisRecursos()
    {
        // Definimos o processador com mais recursos disponíveis o
        // que se colocar em primeiro quando ordenados ascendentemente
        // pelo número de scripts em espera e de seguida por utilização do CPU
        System.out.println("Quantidade de processadores: "+estadosProcessadores.size());
        if(estadosProcessadores.size() < 1)
            return null;
        List<EstadoProcessador> estadosProcessadoresList = new ArrayList<EstadoProcessador>(estadosProcessadores.values());
        EstadoProcessador.order(estadosProcessadoresList);
        return estadosProcessadoresList.get(0);
    }

    private void tratarMensagem(String mensagem){
        String tipo = mensagem.split(":")[0];
        String informacao = mensagem.split(":")[1];
        if(informacao.isEmpty())
            return;

        switch (tipo)
        {
            case "setup":

                this.adicionarProcessador(UUID.fromString(informacao.split(";")[0]), Integer.parseInt(informacao.split(";")[1]));
                break;
            case "resources":
                String[] sEstadoProcessador = informacao.split(";");
                EstadoProcessador estadoProcessador = estadosProcessadores.get(UUID.fromString(sEstadoProcessador[0]));
                if(estadoProcessador==null)
                    return;
                estadoProcessador.setUtilizacaoCPU(Double.parseDouble(sEstadoProcessador[1]));
                estadoProcessador.setScriptsEmEspera(Integer.parseInt(sEstadoProcessador[2]));
                this.guardarRecursosProcessador(estadoProcessador);
                break;
        }
    }
}
