import java.io.IOException;
import java.net.*;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Collections;
import java.util.Enumeration;
import java.util.StringTokenizer;

public class Estabilizador {
    static EstabilizadorServico estabilizador;
    static Registry r;
    public static void main(String[] args) {
        GestorProcessadores gestorProcessadores = new GestorProcessadores();
        gestorProcessadores.start();

        try{
            r = LocateRegistry.createRegistry(3021);
        }catch(RemoteException a){
            a.printStackTrace();
        }

        try{
            estabilizador = new EstabilizadorServico();
            r.rebind("stabilizer", estabilizador);
            System.out.println("Stabilizer server ready");

        }catch(Exception e) {
            System.out.println("Stabilizer server main " + e.getMessage());
        }
    }
}
