import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.RMIClientSocketFactory;
import java.rmi.server.RMIServerSocketFactory;
import java.rmi.server.UnicastRemoteObject;

public class EstabilizadorServico extends UnicastRemoteObject implements EstabilizadorInterface {
    GestorProcessadores gestorProcessadores = new GestorProcessadores();
    protected EstabilizadorServico () throws RemoteException {

    }

    protected EstabilizadorServico(int port) throws RemoteException {
        super(port);
    }

    protected EstabilizadorServico(int port, RMIClientSocketFactory csf, RMIServerSocketFactory ssf) throws RemoteException {
        super(port, csf, ssf);
    }

    @Override
    public String correrScript(Script script) throws RemoteException {
        EstadoProcessador processadorMaisRecursos = gestorProcessadores.obterProcessadorMaisRecursos();
        try {
            ProcessadorInterface p = (ProcessadorInterface) Naming.lookup("rmi://localhost:"+processadorMaisRecursos.getPort()+"/processor");
            p.correrScript(script);
            return processadorMaisRecursos.getObjectID().toString();
        } catch (NotBoundException e) {
            e.printStackTrace();
            return "";
        } catch (MalformedURLException e) {
            e.printStackTrace();
            return "";
        }
    }
}
