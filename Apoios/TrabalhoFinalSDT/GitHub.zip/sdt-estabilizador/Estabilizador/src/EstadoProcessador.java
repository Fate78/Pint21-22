import java.util.*;

public class EstadoProcessador {
    private int port;
    private UUID objectID;
    private double utilizacaoCPU;
    private int scriptsEmEspera;
    private Date ultimoHeartbeat;

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public UUID getObjectID() {
        return objectID;
    }

    public void setObjectID(UUID objectID) {
        this.objectID = objectID;
    }

    public double getUtilizacaoCPU() {
        return utilizacaoCPU;
    }

    public void setUtilizacaoCPU(double utilizacaoCPU) {
        this.utilizacaoCPU = utilizacaoCPU;
    }

    public int getScriptsEmEspera() {
        return scriptsEmEspera;
    }

    public void setScriptsEmEspera(int scriptsEmEspera) {
        this.scriptsEmEspera = scriptsEmEspera;
    }

    public EstadoProcessador(UUID objectID, int port, double utilizacaoCPU, int scriptsEmEspera) {
        this.objectID = objectID;
        this.utilizacaoCPU = utilizacaoCPU;
        this.scriptsEmEspera = scriptsEmEspera;
        this.ultimoHeartbeat = new Date();
    }

    public EstadoProcessador(UUID objectID, int port) {
        this.port = port;
        this.objectID = objectID;
        this.utilizacaoCPU = 0.0;
        this.scriptsEmEspera = 0;
        this.ultimoHeartbeat = new Date();
    }

    public boolean verificaAtivo()
    {
        return ((new Date().getTime() - this.ultimoHeartbeat.getTime())/1000) < 30;
    }

    public static void order(List<EstadoProcessador> persons) {

        Collections.sort(persons, new Comparator() {

            public int compare(Object o1, Object o2) {

                Integer x1 = ((EstadoProcessador) o1).getScriptsEmEspera();
                Integer x2 = ((EstadoProcessador) o2).getScriptsEmEspera();
                int sComp = x1.compareTo(x2);

                if (sComp != 0) {
                    return sComp;
                }

                Double z1 = ((EstadoProcessador) o1).getUtilizacaoCPU();
                Double z2 = ((EstadoProcessador) o2).getUtilizacaoCPU();
                return z1.compareTo(z2);
            }});
    }
}
