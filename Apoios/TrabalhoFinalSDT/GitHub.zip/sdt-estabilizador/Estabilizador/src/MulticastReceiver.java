import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

public class MulticastReceiver extends Thread {
    protected MulticastSocket socket = null;
    protected byte[] buf = new byte[256];
    private String ipGroup;
    private int port;
    private CallbackMulticast callback;

    public MulticastReceiver(String ipGroup_, int port_, CallbackMulticast callback_ )
    {
        this.ipGroup = ipGroup_;
        this.port = port_;
        this.callback = callback_;
    }

    public void run() {
        try {
            socket = new MulticastSocket(port);
        InetAddress group = InetAddress.getByName(ipGroup);
        socket.joinGroup(group);
        while (true) {
            DatagramPacket packet = new DatagramPacket(buf, buf.length);
            socket.receive(packet);
            String received = new String(
                    packet.getData(), 0, packet.getLength());
            System.out.println(received);
            callback.onMessageReceived(received);
            if ("end".equals(received)) {
                break;
            }
            /*
            received = "setup:5bd672f0-af73-40b0-8a13-4dc411edbc56:2021";

            callback.onMessageReceived(received);

            received = "resources:5bd672f0-af73-40b0-8a13-4dc411edbc56;0.8;7";

            callback.onMessageReceived(received);
            received = "setup:5bd672f0-af73-40b0-8a13-4dc411edbc46";

            callback.onMessageReceived(received);*/
        }
        //socket.leaveGroup(group);
        //socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
