import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.nio.file.Files;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.util.ArrayList;
import java.util.UUID;

public class Script implements Serializable {
    private String objectID;
    private String script;
    private ArrayList<String> ficheiros;
    private static final long serialVersionUID = 2;

    public Script(String script, ArrayList<String> ficheiros) {
        this.objectID = UUID.randomUUID().toString();
        this.script = script;
        this.ficheiros = ficheiros;
    }

    public ArrayList<String> getFicheiros() {
        return ficheiros;
    }

    public void setFicheiros(ArrayList<String> ficheiros) {
        this.ficheiros = ficheiros;
    }

    public Script(String script) {
        this.script = script;
        this.objectID = UUID.randomUUID().toString();
        this.ficheiros = new ArrayList<String>();
    }

    public String getObjectID() {
        return objectID;
    }

    public void setObjectID(String objectID) {
        this.objectID = objectID;
    }

    public String getScript() {
        return script;
    }

    public void setScript(String script) {
        this.script = script;
    }


}
