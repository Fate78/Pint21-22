import org.apache.ftpserver.FtpServer;
import org.apache.ftpserver.FtpServerFactory;
import org.apache.ftpserver.ftplet.FtpException;
import org.apache.ftpserver.listener.ListenerFactory;
import org.apache.ftpserver.ssl.SslConfigurationFactory;
import org.apache.ftpserver.usermanager.PropertiesUserManagerFactory;
import org.apache.log4j.PropertyConfigurator;

import java.io.File;
import java.rmi.registry.Registry;


public class Carregador {
    static FtpServerFactory serverFactory = new FtpServerFactory();
    static ListenerFactory factory = new ListenerFactory();
    static Registry r;
    public static void main(String[] args)
    {
            factory.setPort(2221);

            String log4jConfPath = "conf/log4j.properties";
            PropertyConfigurator.configure(log4jConfPath);

            SslConfigurationFactory ssl = new SslConfigurationFactory();
            ssl.setKeystoreFile(new File("conf/ftpserver.jks"));
            ssl.setKeystorePassword("password");

            factory.setSslConfiguration(ssl.createSslConfiguration());
            factory.setImplicitSsl(true);

            serverFactory.addListener("default", factory.createListener());
            PropertiesUserManagerFactory userManagerFactory = new PropertiesUserManagerFactory();
            userManagerFactory.setFile(new File("conf/myusers.properties"));
            serverFactory.setUserManager(userManagerFactory.createUserManager());


        try{
            FtpServer server = serverFactory.createServer();
            server.start();

            System.out.println("Loader server ready");
        }catch(FtpException e) {
            System.out.println("Loader server main " + e.getMessage());
        }
    }
}
