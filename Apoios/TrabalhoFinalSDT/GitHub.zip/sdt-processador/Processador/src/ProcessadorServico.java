import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.RMIClientSocketFactory;
import java.rmi.server.RMIServerSocketFactory;
import java.rmi.server.UnicastRemoteObject;
import java.util.LinkedList;
import java.util.Queue;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import bsh.EvalError;
import com.sun.management.OperatingSystemMXBean;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;

public class ProcessadorServico extends UnicastRemoteObject implements ProcessadorInterface{

    Queue<Script> scriptsEmEspera = new LinkedList<Script>();
    final UUID idProcessador = UUID.randomUUID();
    GestorRecursos gestorRecursos = new GestorRecursos(idProcessador);
    GestorProcessos gestorProcessos = new GestorProcessos(scriptsEmEspera, gestorRecursos, idProcessador);
    GestorProcessadores gestorProcessadores = new GestorProcessadores();
    GestorCerebros gestorCerebros = new GestorCerebros();

    protected ProcessadorServico() throws RemoteException {
        gestorRecursos.start();
        gestorProcessos.start();
        gestorRecursos.definirGestorProcessos(gestorProcessos);
        gestorCerebros.start();
    }

    protected ProcessadorServico(int port) throws RemoteException {
        super(port);
        gestorRecursos.start();
        gestorProcessos.start();
        gestorRecursos.definirGestorProcessos(gestorProcessos);
        gestorCerebros.start();
    }

    protected ProcessadorServico(int port, RMIClientSocketFactory csf, RMIServerSocketFactory ssf) throws RemoteException {
        super(port, csf, ssf);
        gestorRecursos.start();
        gestorProcessos.start();
        gestorRecursos.definirGestorProcessos(gestorProcessos);
        gestorCerebros.start();
    }

    public String correrScript(Script s)
    {
        if(gestorRecursos.temRecursosDisponiveis() && scriptsEmEspera.isEmpty())
        {
            try {
                s.executar(idProcessador.toString());
            } catch (EvalError | IOException | NotBoundException evalError) {
                evalError.printStackTrace();
            }
        }
        else{
            scriptsEmEspera.add(s);
        }
        return s.getObjectID();
    }

    @Override
    public void substituirProcessador(String objectIDProcessador) throws RemoteException, MalformedURLException, NotBoundException {
        CerebroInterface cerebro = (CerebroInterface) Naming.lookup("rmi://localhost:3021/brain");
        String[] scriptsPorCompletar = cerebro.pedirModelosIncompletosProcessador(objectIDProcessador);
    }   

}
