import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class MulticastPublisher {
    private DatagramSocket socket;
    private String ipGroup;
    private int port;
    private byte[] buf;

    public MulticastPublisher(String ipGroup_, int port_) {
        this.ipGroup = ipGroup_;
        this.port = port_;
    }

    public void multicast(String multicastMessage) throws IOException {
        try {
            socket = new DatagramSocket();
            InetAddress group = InetAddress.getByName(ipGroup);
        buf = multicastMessage.getBytes();

        DatagramPacket packet
                = new DatagramPacket(buf, buf.length, group, port);

        socket.send(packet);

        socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}