import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class GestorCerebros extends Thread{
    private MulticastReceiver multicastReceiver;
    private MulticastPublisher multicastPublisher;
    private HashMap<UUID, String> listaCerebros = new HashMap<UUID, String>();

    public GestorCerebros()
    {
        multicastReceiver = new MulticastReceiver("230.0.0.1", 4446, new CallbackMulticast() {
            @Override
            public void onMessageReceived(String message) {
                tratarMensagem(message);
            }
        });
        multicastReceiver.start();
        multicastPublisher = new MulticastPublisher("230.0.0.1", 4446);
    }

    public void run()
    {
        while(true) {
            try {
                TimeUnit.SECONDS.sleep(1);
                multicastPublisher.multicast("hi");
                System.out.println("Estou à procura de cérebros");
            } catch (InterruptedException | IOException e) {
                e.printStackTrace();
            }
        }
    }

    public HashMap<UUID, String> obterCerebros()
    {
        return listaCerebros;
    }

    private void tratarMensagem(String mensagem){
        System.out.println(mensagem);
        String tipo = mensagem.split(":")[0];
        String informacao = mensagem.split(":")[1];
        if(informacao.isEmpty())
            return;

        switch (tipo)
        {
            case "hello":
                System.out.println("Encontrei um cérebro");
                this.listaCerebros.put(UUID.fromString(informacao.split(";")[0]), informacao.split(";")[1]);
                System.out.println("Número de cérebros: " + listaCerebros.size());
                break;
        }
    }
}
