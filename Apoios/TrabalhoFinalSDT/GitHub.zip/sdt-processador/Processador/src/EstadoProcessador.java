import java.util.UUID;

public class EstadoProcessador {
    private int port;
    private UUID objectID;
    private double utilizacaoCPU;
    private int scriptsEmEspera;

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public UUID getObjectID() {
        return objectID;
    }

    public void setObjectID(UUID objectID) {
        this.objectID = objectID;
    }

    public double getUtilizacaoCPU() {
        return utilizacaoCPU;
    }

    public void setUtilizacaoCPU(double utilizacaoCPU) {
        this.utilizacaoCPU = utilizacaoCPU;
    }

    public int getScriptsEmEspera() {
        return scriptsEmEspera;
    }

    public void setScriptsEmEspera(int scriptsEmEspera) {
        this.scriptsEmEspera = scriptsEmEspera;
    }

    public EstadoProcessador(UUID objectID, int port, double utilizacaoCPU, int scriptsEmEspera) {
        this.objectID = objectID;
        this.utilizacaoCPU = utilizacaoCPU;
        this.scriptsEmEspera = scriptsEmEspera;
    }

    public EstadoProcessador(UUID objectID, int port) {
        this.port = port;
        this.objectID = objectID;
        this.utilizacaoCPU = 0.0;
        this.scriptsEmEspera = 0;
    }
}
