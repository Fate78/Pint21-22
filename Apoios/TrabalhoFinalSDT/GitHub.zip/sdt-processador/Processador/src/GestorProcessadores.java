import java.util.HashMap;
import java.util.UUID;

public class GestorProcessadores {

    private HashMap<UUID, EstadoProcessador> estadosProcessadores = new HashMap<>();
    private MulticastReceiver multicastReceiver;

    public GestorProcessadores()
    {
        multicastReceiver = new MulticastReceiver("230.0.0.0", 4446, new CallbackMulticast() {
            @Override
            public void onMessageReceived(String message) {
                tratarMensagem(message);
            }
        });
        multicastReceiver.start();
    }

    public void adicionarProcessador(UUID objectID, int port)
    {
        estadosProcessadores.put(objectID, new EstadoProcessador(objectID, port));
    }

    public void guardarRecursosProcessador(EstadoProcessador estadoProcessador) {
        estadosProcessadores.put(estadoProcessador.getObjectID(), estadoProcessador);
          }

    private void tratarMensagem(String mensagem){
        String tipo = mensagem.split(":")[0];
        String informacao = mensagem.split(":")[1];
        if(informacao.isEmpty())
            return;

        switch (tipo)
        {
            case "setup":
                this.adicionarProcessador(UUID.fromString(informacao.split(";")[0]), Integer.parseInt(informacao.split(";")[1]));
                break;
            case "resources":
                String[] sEstadoProcessador = informacao.split(";");
                EstadoProcessador estadoProcessador = estadosProcessadores.get(UUID.fromString(sEstadoProcessador[0]));
                if(estadoProcessador==null)
                    return;
                estadoProcessador.setUtilizacaoCPU(Double.parseDouble(sEstadoProcessador[1]));
                estadoProcessador.setScriptsEmEspera(Integer.parseInt(sEstadoProcessador[2]));
                this.guardarRecursosProcessador(estadoProcessador);
                break;
        }
    }
}
