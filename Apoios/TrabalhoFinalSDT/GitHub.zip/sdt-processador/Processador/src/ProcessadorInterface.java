import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ProcessadorInterface extends Remote {
    public String correrScript(Script script) throws RemoteException;
    public void substituirProcessador (String objectIDProcessador) throws RemoteException, MalformedURLException, NotBoundException;
}
