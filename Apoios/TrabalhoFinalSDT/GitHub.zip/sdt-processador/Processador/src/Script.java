import java.io.*;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.rmi.*;
import java.util.ArrayList;
import java.util.UUID;

import bsh.EvalError;
import bsh.Interpreter;
import org.apache.commons.net.ftp.FTPSClient;

public class Script implements Serializable {
    private String objectID;
    private String script;
    private ArrayList<String> ficheiros;
    private static final long serialVersionUID = 2;

    private String objectIDProcessador;

    public Script(String script, ArrayList<String> ficheiros) {
        this.objectID = UUID.randomUUID().toString();
        this.script = script;
        this.ficheiros = ficheiros;
    }

    public ArrayList<String> getFicheiros() {
        return ficheiros;
    }

    public void setFicheiros(ArrayList<String> ficheiros) {
        this.ficheiros = ficheiros;
    }

    public Script(String script) {
        this.script = script;
        this.objectID = UUID.randomUUID().toString();
        this.ficheiros = new ArrayList<String>();
    }

    public Script(String script, String objectIDProcessador) {
        this.script = script;
        this.objectID = UUID.randomUUID().toString();
        this.ficheiros = new ArrayList<String>();
        this.objectIDProcessador = objectIDProcessador;
    }

    public String getObjectID() {
        return objectID;
    }

    public void setObjectID(String objectID) {
        this.objectID = objectID;
    }

    public String getObjectIDProcessador() {
        return objectIDProcessador;
    }

    public void setObjectIDProcessador(String objectIDProcessador) {
        this.objectIDProcessador = objectIDProcessador;
    }

    public String getScript() {
        return script;
    }

    public void setScript(String script) {
        this.script = script;
    }

    public void executar(String objectIDProcessador) throws EvalError, IOException, NotBoundException {
        if(!this.objectIDProcessador.isEmpty())
            this.obterDados();
        this.setObjectIDProcessador(objectIDProcessador);
        Interpreter interpreter = new Interpreter();
        Object res = interpreter.eval(this.script);
        this.guardarModelo();
    }

    public void obterDados() throws IOException {
        if(this.ficheiros.isEmpty())
            return;
        FTPSClient client = new FTPSClient(true);
        client.connect("localhost", 2221);
        client.login("processor", "sdt2021");

        for(String ficheiro : this.getFicheiros()) {
            if (client.isConnected()) {
                try (FileOutputStream fos = new FileOutputStream("/files/" + this.getObjectID() + "/" +ficheiro)) {
                    client.retrieveFile(ficheiro, fos);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    public void guardarModelo() throws IOException, NotBoundException {
        CerebroInterface cerebro = (CerebroInterface) Naming.lookup("rmi://localhost:2023/brain");
        File f = new File("/home/processador/models/"+objectID);
        byte[] conteudoFicheiro = Files.readAllBytes(f.toPath());
        cerebro.guardarModelo(conteudoFicheiro, objectID, objectIDProcessador, true);
    }

    public boolean obterModelo() throws IOException, NotBoundException {
        CerebroInterface cerebro = (CerebroInterface) Naming.lookup("rmi://localhost:2023/brain");
        byte[] modelo = cerebro.pedirModelo(objectID, objectIDProcessador);
        File f =new File("/home/processador/models/"+objectID);
        f.createNewFile();
        FileOutputStream out = new FileOutputStream(f,true);
        out.write(modelo,0,modelo.length);
        out.flush();
        out.close();
        return true;
    }

}
