import bsh.EvalError;

import java.io.IOException;
import java.rmi.NotBoundException;
import java.util.LinkedList;
import java.util.Queue;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class GestorProcessos extends Thread{
    GestorRecursos gestorRecursos;
    Queue<Script> scriptsEmEspera;
    String idProcessador;
    public GestorProcessos(Queue<Script> scriptsEmEspera_, GestorRecursos gestorRecursos_, UUID idProcessador_) {
        this.gestorRecursos = gestorRecursos_;
        this.scriptsEmEspera = scriptsEmEspera_;
        this.idProcessador = idProcessador_.toString();
    }

    public void run()
    {
        while(true) {
            // Verifica a constantemente se há scripts em espera para serem corridos
            try {
                TimeUnit.MILLISECONDS.sleep(1);
                if(gestorRecursos.temRecursosDisponiveis() && !scriptsEmEspera.isEmpty())
                {
                    scriptsEmEspera.poll().executar(idProcessador);
                }
            } catch (InterruptedException | EvalError | IOException | NotBoundException e) {
            }
        }
    }

    public int obterNumeroScriptsEmEspera()
    {
        return scriptsEmEspera.size();
    }
}
