import com.sun.management.OperatingSystemMXBean;

import java.io.File;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.ArrayList;
import java.util.Queue;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class GestorRecursos extends Thread{

    final int MAX_UTILIZACAO_CPU = 80; // Percentagem máxima de utilização de CPU para execução de novos scripts
    final int MIN_ESPACO_DISCO = 5; // Mínimo de GB livres para a execução de novos scripts

    double mediaProcessador;
    double espacoLivreDisco;

    static ArrayList<Double> leiturasProcessador = new ArrayList<Double>();

    static OperatingSystemMXBean osBean = ManagementFactory.getPlatformMXBean(
            OperatingSystemMXBean.class);

    GestorProcessos gestorProcessos;

    UUID idProcessador; // = UUID.randomUUID();
    int portProcessador = 2021;

    MulticastPublisher multicastPublisher = new MulticastPublisher("230.0.0.0", 4446);

    public GestorRecursos(UUID idProcessador_) {
        this.idProcessador = idProcessador_;
        heartbeatSetup();
    }

    public void run()
    {
        while(true) {
            // Faz 5 leituras, com intervalos de 1 segundo da utilização do CPU
            try {
                TimeUnit.SECONDS.sleep(1);
                leiturasProcessador.add(0, osBean.getSystemCpuLoad());
                if (leiturasProcessador.size() > 5)
                    leiturasProcessador.remove(5);
                calcularRecursos();
                heartbeatRecursos();
            } catch (InterruptedException e) {
            }
        }
    }

    public void definirGestorProcessos(GestorProcessos gestorProcessos_)
    {
        this.gestorProcessos = gestorProcessos_;
    }

    public void calcularRecursos()
    {
        // Obter utilização do CPU
        osBean.getSystemCpuLoad();
        mediaProcessador = 0;
        for(int i = 0; i < leiturasProcessador.size(); i++)
        {
            mediaProcessador += leiturasProcessador.get(0);
        }
        System.out.println("media: "+mediaProcessador+"; leiturasProcessador.size(): "+leiturasProcessador.size() + "; leiturasProcessador: "+leiturasProcessador);
        mediaProcessador = Math.round((mediaProcessador / leiturasProcessador.size()) * 10000);
        mediaProcessador = mediaProcessador/100;

        // Obter espaço livre em disco
        File f = new File("C:\\");
        espacoLivreDisco = f.getFreeSpace()/1024/1024;
    }

    public void heartbeatRecursos()
    {
        try {
            multicastPublisher.multicast("resources:"+idProcessador + ";" + mediaProcessador + ";" + gestorProcessos.obterNumeroScriptsEmEspera() );
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void heartbeatSetup()
    {
        try {
            multicastPublisher.multicast("setup:"+idProcessador+";"+portProcessador);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean temRecursosDisponiveis(){
        if(mediaProcessador > MAX_UTILIZACAO_CPU || espacoLivreDisco < MIN_ESPACO_DISCO)
            return false;
        return true;
    }
}
