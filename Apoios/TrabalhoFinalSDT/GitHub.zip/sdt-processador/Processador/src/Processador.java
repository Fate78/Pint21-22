import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.UUID;
import java.util.concurrent.TimeUnit;


public class Processador {
    static ProcessadorServico processor;
    static Registry r;
    public static void main(String[] args)
    {
        try{
            r = LocateRegistry.createRegistry(2021);
        }catch(RemoteException a){
            a.printStackTrace();
        }

        try{
            processor = new ProcessadorServico(2021);
            r.rebind("processor", processor);
            System.out.println("Processor server ready");

        }catch(Exception e) {
            System.out.println("Processor server main " + e.getMessage());
        }
    }
}
