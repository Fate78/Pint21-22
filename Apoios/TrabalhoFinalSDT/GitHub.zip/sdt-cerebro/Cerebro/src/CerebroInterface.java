import java.io.IOException;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface CerebroInterface extends Remote {
    public boolean guardarModelo(byte[] dados, String objectIDScript, String objectIDProcessador, boolean completo) throws IOException, RemoteException;
    public byte[] pedirModelo(String objectIDScript, String objectIDProcessador) throws IOException, RemoteException;
    public String[] pedirModelosIncompletosProcessador(String objectIDProcessador) throws RemoteException;
}
