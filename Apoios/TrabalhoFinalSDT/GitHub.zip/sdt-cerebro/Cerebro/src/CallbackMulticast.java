public interface CallbackMulticast {
    void onMessageReceived(String message);
}