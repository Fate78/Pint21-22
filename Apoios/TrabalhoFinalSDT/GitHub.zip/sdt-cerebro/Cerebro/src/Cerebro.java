import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Cerebro {
    static CerebroServico brain;
    static Registry r;
    public static void main(String[] args)
    {
        try{
            r = LocateRegistry.createRegistry(2023);
        }catch(RemoteException a){
            a.printStackTrace();
        }

        try{
            brain = new CerebroServico();
            r.rebind("brain", brain);

            System.out.println("Brain server ready");
        }catch(Exception e) {
            System.out.println("Brain server main " + e.getMessage());
        }
    }
}
