import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.rmi.RemoteException;
import java.rmi.server.RMIClientSocketFactory;
import java.rmi.server.RMIServerSocketFactory;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.UUID;

public class CerebroServico extends UnicastRemoteObject implements CerebroInterface {

    private MulticastReceiver multicastReceiver;
    private MulticastPublisher multicastPublisher;
    UUID idCerebro = UUID.randomUUID();
    int portCerebro = 2023;

    protected CerebroServico() throws RemoteException {
        multicastReceiver = new MulticastReceiver("230.0.0.1", 4446, new CallbackMulticast() {
            @Override
            public void onMessageReceived(String message) {
                System.out.println("Recebi mensagem.");
                tratarMensagem(message);
            }
        });
        multicastReceiver.start();
        multicastPublisher = new MulticastPublisher("230.0.0.1", 4446);
    }

    protected CerebroServico(int port) throws RemoteException {
        super(port);
        multicastReceiver = new MulticastReceiver("230.0.0.1", 4446, new CallbackMulticast() {
            @Override
            public void onMessageReceived(String message) {
                tratarMensagem(message);
            }
        });
        multicastReceiver.start();
        multicastPublisher = new MulticastPublisher("230.0.0.1", 4446);
    }

    protected CerebroServico(int port, RMIClientSocketFactory csf, RMIServerSocketFactory ssf) throws RemoteException {
        super(port, csf, ssf);
        multicastReceiver = new MulticastReceiver("230.0.0.1", 4446, new CallbackMulticast() {
            @Override
            public void onMessageReceived(String message) {
                tratarMensagem(message);
            }
        });
        multicastReceiver.start();
        multicastPublisher = new MulticastPublisher("230.0.0.1", 4446);
    }

    public boolean guardarModelo(byte[] modelo, String objectIDScript, String objectIDProcessador, boolean completo) throws IOException {
        File f;
        if(completo) {
            File old = new File("/home/cerebro/models/"+objectIDProcessador+"/incomplete/"+objectIDScript);
            old.delete();
            f = new File("/home/cerebro/models/" + objectIDProcessador + "/complete/" + objectIDScript);
        }
        else f =new File("/home/cerebro/models/"+objectIDProcessador+"/incomplete/"+objectIDScript);

        f.getParentFile().mkdirs();
        f.createNewFile();
        FileOutputStream out = new FileOutputStream(f,true);
        out.write(modelo,0,modelo.length);
        out.flush();
        out.close();
        return true;
    }

    public byte[] pedirModelo(String objectIDScript, String objectIDProcessador) throws IOException {
        File f = new File("/home/cerebro/models/"+objectIDProcessador+"/complete/"+objectIDScript);
        if(!f.exists() || f.isDirectory())
            f = new File("/home/cerebro/models/"+objectIDProcessador+"/incomplete/"+objectIDScript);
        byte[] conteudoFicheiro = Files.readAllBytes(f.toPath());
        return conteudoFicheiro;
    }

    @Override
    public String[] pedirModelosIncompletosProcessador(String objectIDProcessador) throws RemoteException {
        File folder = new File("/home/cerebro/models/"+objectIDProcessador+"/incomplete/");
        File[] listaDeFicheiros = folder.listFiles();
        ArrayList<String> listaDeScripts = new ArrayList<String>();
        for (final File fileEntry : folder.listFiles()) {
            listaDeScripts.add(fileEntry.getName());
        }
        return listaDeScripts.toArray(new String[0]);
    }

    private void tratarMensagem(String mensagem){
        System.out.println(mensagem);
        switch (mensagem)
        {
            case "hi":
                System.out.println("Chamaram por mim");
                try {
                    multicastPublisher.multicast("hello:"+idCerebro+";"+portCerebro);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
        }
    }
}
